﻿using GoodSupplyWEB.Models.DB;
using GoodSupplyWEB.ViewModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace GoodSupplyWEB.Controllers
{
    public class BinPackingController : Controller
    {
        public int truckL { get; set; }

        List<double> numbersW;
        List<double> numbersL;
        List<double> numbersH;

        public class Bin
        {
            public string CatalogNum;
            public int BinNumber;
            public int FrameNumber;
        }

        public class Package
        {
            public int packWidth;
            public int packLength;
            public int packHeigth;
            public string CatalogNum;
            public bool isOccupied = false;
        }

        public void Packer(List<Package> packages, int truckWidth, int truckLength, int truckHeigth)
        {
            //Console.WriteLine("אורך עדכני " + truckLength);

            int frame = 1;

            Console.WriteLine("Packeges from the order: ");
            foreach (var item in packages)
                Console.Write(" W " + item.packWidth); // Replace this with your version of printing
            Console.WriteLine();
            foreach (var item in packages)
                Console.Write(" L " + item.packLength); // Replace this with your version of printing
            Console.WriteLine();
            foreach (var item in packages)
                Console.Write(" H " + item.packHeigth); // Replace this with your version of printing
            Console.WriteLine();


            numbersW = new List<double>(packages.Count);
            numbersL = new List<double>(packages.Count);
            numbersH = new List<double>(packages.Count);

            // 3	נכניס ב-3 מערכים שונים (arrWidth, arrLength,arrHeigth ) את המימדים מכל החבילות בלולאת for 
            for (int i = 0; i < packages.Count; i++)
            {
                numbersW.Add(packages[i].packWidth);
                numbersL.Add(packages[i].packLength);
                numbersH.Add(packages[i].packHeigth);
            }

            numbersW.Sort();
            numbersL.Sort();
            numbersH.Sort();


            double tempWidth;
            double tempLength;
            double tempHeigth;

            if (packages.Count > 1)
            {
                tempWidth = numbersW.Last() / numbersW.First();
                Console.WriteLine("proportion of W:" + tempWidth);
                tempLength = numbersL.Last() / numbersL.First();
                Console.WriteLine("proportion of L:" + tempLength);
                tempHeigth = numbersH.Last() / numbersH.First();
                Console.WriteLine("proportion of H:" + tempHeigth);
            }
            else
            {
                tempWidth = numbersW.Last();
                Console.WriteLine("proportion of W:" + tempWidth);
                tempLength = numbersL.Last();
                Console.WriteLine("proportion of L:" + tempLength);
                tempHeigth = numbersH.Last();
                Console.WriteLine("proportion of H:" + tempHeigth);

            }

            int binWidth = 0;
            int binLength = 0;
            int binHeigth = 0;

            Boolean swapWL = false;
            Boolean swapWH = false;
            Boolean swapLH = false;

            Console.WriteLine();
            Console.WriteLine("Size of bin: ");

            //למציאת ערך קטן ועדכון אורך חדש
            if (tempWidth < tempLength && tempWidth < tempHeigth)
            {
                binLength = (int)numbersW.Last();
                changeWidthLength(packages);      //change column width with column length
                swapWL = true;

                if (tempLength < tempHeigth)
                {
                    binWidth = (int)numbersH.Last();
                    binHeigth = (int)numbersL.Last();
                    changeWidhtHeigth(packages);
                }
                else if (tempLength > tempHeigth)
                {
                    binWidth = (int)numbersL.Last();
                    binHeigth = (int)numbersH.Last();
                    //changeLengthHeigth(packages);
                }
                else
                {
                    binWidth = (int)numbersW.Last();
                    binHeigth = (int)numbersH.Last();
                }
            }
            else if (tempLength < tempWidth && tempLength < tempHeigth)
            {
                binLength = (int)numbersL.Last();

                if (tempWidth < tempHeigth)
                {
                    binWidth = (int)numbersH.Last();
                    binHeigth = (int)numbersW.Last();
                    changeWidhtHeigth(packages);    //change column width with column heigth
                }
                else if (tempWidth > tempHeigth)
                {
                    binWidth = (int)numbersW.Last();
                    binHeigth = (int)numbersH.Last();
                    //changeWidhtHeigth(packages);    //change column width with column heigth
                }
                else
                {
                    binWidth = (int)numbersW.Last();
                    binHeigth = (int)numbersH.Last();
                }
            }
            else if (tempHeigth < tempWidth && tempHeigth < tempLength)
            {
                binLength = (int)numbersH.Last();
                changeLengthHeigth(packages);      //change column heigth with column length
                swapLH = true;

                if (tempWidth < tempLength)
                {
                    binWidth = (int)numbersL.Last();
                    binHeigth = (int)numbersW.Last();
                    changeWidhtHeigth(packages);    //change column width with column heigth
                }
                else if (tempWidth > tempLength)
                {
                    binWidth = (int)numbersW.Last();
                    binHeigth = (int)numbersL.Last();
                    //changeWidthLength(packages);      //change column width with column length
                }
                else
                {
                    binWidth = (int)numbersW.Last();
                    binHeigth = (int)numbersH.Last();
                }
            }
            else if (tempHeigth == tempWidth && !(tempWidth == tempLength))
            {
                if (tempLength > tempWidth)
                {
                    binWidth = (int)numbersL.Last();
                    binLength = (int)numbersW.Last();
                    changeWidthLength(packages);      //change column width with column length
                }
                else if (tempLength < tempWidth)
                {
                    binLength = (int)numbersL.Last();
                    binWidth = (int)numbersW.Last();
                }
                binHeigth = (int)numbersH.Last();
            }
            else if (!(tempHeigth == tempWidth) && tempHeigth == tempLength)
            {
                if (tempWidth > tempLength)
                {
                    binWidth = (int)numbersW.Last();
                    binLength = (int)numbersL.Last();
                }
                else if (tempWidth < tempLength)
                {
                    binWidth = (int)numbersL.Last();
                    binLength = (int)numbersW.Last();
                    changeWidthLength(packages);      //change column width with column length
                }
                binHeigth = (int)numbersH.Last();

            }
            else if (!(tempHeigth == tempWidth) && tempWidth == tempLength)
            {
                if (tempWidth > tempHeigth)
                {
                    binLength = (int)numbersH.Last();
                    binHeigth = (int)numbersL.Last();
                    changeLengthHeigth(packages);
                    binWidth = (int)numbersW.Last();
                }
                else if (tempWidth < tempHeigth)
                {
                    binWidth = (int)numbersH.Last();
                    binHeigth = (int)numbersW.Last();
                    changeWidhtHeigth(packages);
                    binLength = (int)numbersL.Last();
                }

            }
            else if (tempHeigth == tempWidth && tempHeigth == tempLength)
            {
                binLength = (int)numbersL.Last();
                binWidth = (int)numbersW.Last();
                binHeigth = (int)numbersH.Last();
            }

            Console.Write("L " + binLength + ", W " + binWidth + ", H " + binHeigth);
            Console.WriteLine();


            packages.Sort((x, y) => x.packWidth.CompareTo(y.packWidth));
            packages.Reverse();

            truckL = truckL - binLength;   //עדכון אורך במשאית אחרי חישוב משגרת להזמנה 
            Console.WriteLine("Length of truck " + truckL);

            if (truckL >= binLength && truckL > 0)
            {
                Console.WriteLine("Packeges after checking sizes and reverse by width: ");
                foreach (var item in packages)
                    Console.Write(" W " + item.packWidth); // Replace this with your version of printing
                Console.WriteLine();
                foreach (var item in packages)
                    Console.Write(" L " + item.packLength); // Replace this with your version of printing
                Console.WriteLine();
                foreach (var item in packages)
                    Console.Write(" H " + item.packHeigth); // Replace this with your version of printing
                Console.WriteLine();


                //Bins-חישוב מספר ה
                int numberOfBins = truckHeigth / binHeigth;
                Console.WriteLine("Number of bins is:  " + numberOfBins);

                //שליחת נתונים לאלגוריתם בשביל האריזה
                Console.WriteLine();
                Console.WriteLine("Start bin-packing:");
                FirstFit(packages, numberOfBins, frame, truckWidth, truckLength, binWidth, binLength, binHeigth);
            }
            else
            {
                Console.WriteLine("There is no more space in the truck!");
            }
        }

        private void changeLengthHeigth(List<Package> packages)
        {
            var tempVar = 0;
            for (int i = 0; i < packages.Count; i++)
            {
                tempVar = packages[i].packLength;
                packages[i].packLength = packages[i].packHeigth;
                packages[i].packHeigth = tempVar;
            }
        }

        private void changeWidhtHeigth(List<Package> packages)
        {
            var tempVar = 0;
            for (int i = 0; i < packages.Count; i++)
            {
                tempVar = packages[i].packWidth;
                packages[i].packWidth = packages[i].packHeigth;
                packages[i].packHeigth = tempVar;
            }
        }

        private void changeWidthLength(List<Package> packages)
        {
            var tempVar = 0;
            for (int i = 0; i < packages.Count; i++)
            {
                tempVar = packages[i].packWidth;
                packages[i].packWidth = packages[i].packLength;
                packages[i].packLength = tempVar;
            }
        }



        public void FirstFit(List<Package> packages, int bins, int frames, int truckWidth, int truckLength, int binWidth, int binLength, int binHeigth)
        {
            List<Bin> cat = new List<Bin>();
            //משכפל את רשימת החבילות שיש לארוז
            //ישמש אותנו להחזקת חבילות שעוד לא נכנסו לאריזה,אלה שמכניסים נמחוק מהרשימה
            List<Package> temp_pack = new List<Package>(packages.Count);
            temp_pack.AddRange(packages);

            // Initialize result (Count of bins)
            int res = 0;

            // Create an array to store remaining space in bins by WIDTH there can be at most n bins
            int[] bin_remWidth = new int[bins];

            // Create an array to store remaining space in bins by LENGTH there can be at most n bins
            // int[] bin_remLength = new int[bins];

            // Create an array to store remaining space in bins by HEIGTH there can be at most n bins
            //int[] bin_remHeigth = new int[bins];

            int temp_bins = bins;
            // Place items one by one
            for (int i = 0; i < packages.Count; i++)
            {
                // Find the first bin that can accommodate packages[i]
                int j;
                for (j = 0; j < res; j++)
                {
                    if (bin_remWidth[j] >= packages[i].packWidth)
                    {
                        bin_remWidth[j] = bin_remWidth[j] - packages[i].packWidth;
                        break;
                    }
                }

                // If no bin could accommodate packages[i]
                if (j == res && res < bins)
                {
                    bin_remWidth[res] = binWidth - packages[i].packWidth;
                    //Console.WriteLine("Bin_rem: " + bin_rem[res]);

                    // bin_remLength[res] = binLength - packages[i].packLength;   //נבדוק אם יש מקום עוד לפי האורך

                    //bin_remHeigth[res] = binHeigth - packages[i].packHeigth;   //נעדכן גובה שנשארה לנו בתוך מיכל שלנו בשביל שנוכל לבדוק אם אפשר לשים חבילה מעל

                    if (packages[i].isOccupied == false)
                    {
                        packages[i].isOccupied = true;
                        
                        Bin bin = new Bin { BinNumber = res+1, CatalogNum = packages[i].CatalogNum, FrameNumber = frames };
                        cat.Add(bin);
                        Console.WriteLine("pack: " + packages[i].packWidth + " " + packages[i].packLength + " " + packages[i].packHeigth);

                        //נבדוק אם אפשר להכניס לכאן עוד חבילה לפי רוחב הפנוי באותו מיכל
                        if (binWidth - packages[i].packWidth > 0)   // if (binWidth - bin_remWidth[res] > 0)
                        {
                            for (int k = res; k < packages.Count; k++)  //for (int k = res; k < packages.Count; k++)
                            {
                                if (bin_remWidth[res] >= packages[k].packWidth && packages[k].isOccupied != true)
                                {
                                    bin_remWidth[res] = bin_remWidth[res] - packages[k].packWidth;
                                    packages[k].isOccupied = true;
                                    packages[i].isOccupied = true;
                                    bin = new Bin { BinNumber = res+1, CatalogNum = packages[k].CatalogNum, FrameNumber = frames };
                                    cat.Add(bin);
                                    Console.WriteLine("pack: " + packages[k].packWidth + " " + packages[k].packLength + " " + packages[k].packHeigth);

                                    if (bin_remWidth[res] == 0)
                                    {
                                        Console.WriteLine("Delete pack: " + packages[k].packWidth + " " + packages[k].packLength + " " + packages[k].packHeigth);
                                        break;
                                    }
                                    //temp_pack.RemoveAt(k);
                                }
                            }
                        }

                        //freeSpaceInHeigth( packages, binHeigth, bin_remHeigth, res);


                        res++;
                        temp_bins--;
                        Console.WriteLine("Bin number: " + res);
                    }
                    //אם נשארו עוד חבילות ונגמרו מיכלים אז נפתוח מיכל חדש באותה משגרת של הלקוח
                    if (temp_bins == 0 && packagesEnd(packages, res) == true)   // && packagesEnd(packages, res) == true
                    {
                        temp_pack.RemoveRange(0, res);
                        //Console.WriteLine("Num of Bins: " + bins);

                        //שליחת נתונים לאלגוריתם בשביל האריזה
                        if (truckWidth - binWidth >= binWidth && packagesEnd(packages, res) == true)          //(truckWidth - binWidth > 0 && truckWidth - binWidth >= truckWidth)
                        {
                            if (packagesEnd(packages, packages.Count) == true)
                            {
                                break;
                            }
                            Console.WriteLine("A new frame openW: ");
                            FirstFit(temp_pack, bins, frames, truckWidth - binWidth, truckLength, binWidth, binLength, binHeigth);
                        }
                        else if (truckLength - binLength >= binLength && packagesEnd(packages, res) == true)       //(truckLength - binLength > 0 && truckLength - binLength < truckLength)
                        {
                            if (packagesEnd(packages, packages.Count) == true)
                            {
                                break;
                            }
                            Console.WriteLine("A new frame openL: ");
                            FirstFit(temp_pack, bins, frames+1, truckWidth, truckLength - binLength, binWidth, binLength, binHeigth);
                        }
                        else if (truckWidth - binWidth < binWidth && truckLength - binLength < binLength)
                        {
                            Console.WriteLine("There is no more space in the truck!");
                        }

                        if (packagesEnd(packages, res) == false)
                        {
                            Console.WriteLine("End of Bin-Packing!");
                            Console.WriteLine();
                           
                        }
                    }
                    else if (packagesEnd(packages, res) == false)
                    {
                        Console.WriteLine("End of Bin-Packing!");
                        Console.WriteLine();
                    }
                }
            }
            ViewData["ListForSupplier"] = cat;
        }

        public static Boolean packagesEnd(List<Package> packages, int res)    //בודק אם יש עוד חבילות ברשימה
        {
            Boolean temp = false;

            for (int i = res + 1; i < packages.Count; i++)
            {
                if (packages[i].isOccupied == false)   // אם ברשימה באינדקס הבא יש עוד חבילה שלא ארזנו אותה אז נחזיר אמת
                {
                    temp = true;
                    break;
                }
            }
            return temp;
        }


        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        private GoodSupplyEntities db = new GoodSupplyEntities();

        // GET: BinPacking
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult SetByCity(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var supplier = db.Suppliers.Where(s => s.Id == id).FirstOrDefault();
            
            var mySupplierOrders = db.Orders.Where(o => o.SupplierId == supplier.Id && o.SupplierApproval == 1).Include(o => o.Clients).Include(o => o.Suppliers);
            return View(mySupplierOrders.OrderBy(o => o.Clients.BusinessAddress).ToList());           
        }

        [HttpPost]
        public ActionResult SetOrdersPosition(ICollection<BinPackingAlgViewModel> binPackingAlgVM)
        {
            //משתנים קבועים למשאית
            int truckWidth = 70;
            truckL = 100;
            int truckHeigth = 150;

            for (var i = 1; i <= binPackingAlgVM.Count(); i++)
            {
                var currentOrderId = binPackingAlgVM.Where(b => b.Position == i).FirstOrDefault().Id;
                var orderDetails = db.OrderDetails.Where(o => o.OrderId == currentOrderId).ToList();

                List<Package> packages = new List<Package>(orderDetails.Count());

                foreach (var item in orderDetails)
                {
                    //Package p[j] = new Package { packWidth = item.ManufacturerProducts.Width.Value, packLength = item.ManufacturerProducts.Length.Value, packHeigth = item.ManufacturerProducts.Height.Value };
                    Package package = new Package { packWidth = item.ManufacturerProducts.Width.Value, packLength = item.ManufacturerProducts.Length.Value, packHeigth = item.ManufacturerProducts.Height.Value, CatalogNum = item.ManufacturerProducts.CatalogNumber };
                    packages.Add(package);
                    //packages[j].packLength = item.ManufacturerProducts.Length.Value;
                    //packages[j].packHeigth = item.ManufacturerProducts.Height.Value;
                    //packages[j].packWidth = item.ManufacturerProducts.Width.Value;
                    //packages[j].CatalogNum = item.ManufacturerProducts.CatalogNumber.ToString();
                        
                }
                //package.truckL
                Packer(packages, truckWidth, truckL, truckHeigth);
            }

            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
                db.Dispose();
            base.Dispose(disposing);
        }
    }
}