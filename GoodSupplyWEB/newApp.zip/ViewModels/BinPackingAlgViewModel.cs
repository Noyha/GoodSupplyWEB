﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GoodSupplyWEB.ViewModels
{
    public class BinPackingAlgViewModel
    {
        public int Id { get; set; }
        public int Position { get; set; }
    }
}